import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react';
import { currentUser, type Role } from '../data/mockData';

/* ========================================================================
   Auth
======================================================================== */
export type User = {
  id: number;
  name: string;
  email: string;
  role: Role;
  avatar: string;
};

type AuthCtx = {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
};

const AuthContext = createContext<AuthCtx | null>(null);

/* ========================================================================
   Theme
======================================================================== */
type ThemeCtx = { theme: 'light' | 'dark'; toggle: () => void; };
const ThemeContext = createContext<ThemeCtx | null>(null);

/* ========================================================================
   Toast
======================================================================== */
type Toast = { id: number; type: 'success' | 'error' | 'info' | 'warning'; message: string; };
type ToastCtx = { toasts: Toast[]; push: (t: Omit<Toast, 'id'>) => void; dismiss: (id: number) => void; };
const ToastContext = createContext<ToastCtx | null>(null);

/* ========================================================================
   Sidebar (mobile)
======================================================================== */
type SidebarCtx = { open: boolean; setOpen: (v: boolean) => void; };
const SidebarContext = createContext<SidebarCtx | null>(null);

/* ========================================================================
   Provider
======================================================================== */
export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    try { const raw = localStorage.getItem('mc_user'); return raw ? JSON.parse(raw) : null; } catch { return null; }
  });
  const [theme, setTheme] = useState<'light' | 'dark'>(() => (localStorage.getItem('mc_theme') as 'light' | 'dark') || 'light');
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    localStorage.setItem('mc_theme', theme);
  }, [theme]);

  const login = useCallback(async (email: string, _password: string) => {
    // Simulated API call. Wire to authService.login() when Spring Boot is ready.
    await new Promise((r) => setTimeout(r, 900));
    if (!email) throw new Error('Invalid credentials');
    const u = { ...currentUser };
    setUser(u);
    localStorage.setItem('mc_user', JSON.stringify(u));
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    localStorage.removeItem('mc_user');
  }, []);

  const push = useCallback((t: Omit<Toast, 'id'>) => {
    const id = Date.now() + Math.random();
    setToasts((s) => [...s, { ...t, id }]);
    setTimeout(() => setToasts((s) => s.filter((x) => x.id !== id)), 4000);
  }, []);

  const dismiss = useCallback((id: number) => setToasts((s) => s.filter((t) => t.id !== id)), []);

  return (
    <AuthContext.Provider value={{ user, login, logout, isAuthenticated: !!user }}>
      <ThemeContext.Provider value={{ theme, toggle: () => setTheme((t) => (t === 'light' ? 'dark' : 'light')) }}>
        <ToastContext.Provider value={{ toasts, push, dismiss }}>
          <SidebarContext.Provider value={{ open, setOpen }}>
            {children}
          </SidebarContext.Provider>
        </ToastContext.Provider>
      </ThemeContext.Provider>
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const ctx = useContext(AuthContext); if (!ctx) throw new Error('useAuth outside provider'); return ctx;
};
export const useTheme = () => {
  const ctx = useContext(ThemeContext); if (!ctx) throw new Error('useTheme outside provider'); return ctx;
};
export const useToast = () => {
  const ctx = useContext(ToastContext); if (!ctx) throw new Error('useToast outside provider'); return ctx;
};
export const useSidebar = () => {
  const ctx = useContext(SidebarContext); if (!ctx) throw new Error('useSidebar outside provider'); return ctx;
};
